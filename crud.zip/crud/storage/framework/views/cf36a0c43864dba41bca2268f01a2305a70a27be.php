<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Student Details</h1>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($student->fname); ?> <?php echo e($student->lname); ?></h5>
                        <p class="card-text"><strong>Gender:</strong> <?php echo e($student->gender); ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo e($student->email); ?></p>
                        <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST" style="display: inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-link">Back to all students</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>