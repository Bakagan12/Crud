<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Students</h1>
                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success mb-3">Create Student</a>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->id); ?></td>
                                <td><?php echo e($student->fname); ?></td>
                                <td><?php echo e($student->lname); ?></td>
                                <td><?php echo e($student->gender); ?></td>
                                <td><?php echo e($student->email); ?></td>
                                <td>
                                    <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
                                        <a href="<?php echo e(route('students.show', $student->id)); ?>" class="btn btn-info">Show</a>
                                        <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary">Edit</a>
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>