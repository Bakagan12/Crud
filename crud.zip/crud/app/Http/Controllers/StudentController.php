<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student;

class StudentController extends Controller
{
    public function index()
    {
        $students = Student::all();
        return view('students.index', compact('students'));
    }

    public function create()
    {
        return view('students.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'fname' => 'required',
            'lname' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:students',
        ]);

        Student::create($request->all());

        return redirect()->route('students.index')
                         ->with('success','Student created successfully.');
    }

    public function show($id)
    {
        $student = Student::find($id);
        return view('students.show', compact('student'));
    }

    public function edit($id)
    {
        $student = Student::find($id);
        return view('students.edit', compact('student'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'fname' => 'required',
            'lname' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:students,email,'.$id,
        ]);

        Student::find($id)->update($request->all());

        return redirect()->route('students.index')
                         ->with('success','Student updated successfully');
    }

    public function destroy($id)
    {
        Student::find($id)->delete();

        return redirect()->route('students.index')
                         ->with('success','Student deleted successfully');
    }
}
